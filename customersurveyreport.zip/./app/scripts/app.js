const questions = [
  "let me know your name, Buddy?",
  "Where are you from?",
  "How satisfied are you with the overall quality of our product?",
  "How likely are you to recommend our product to others?",
  "Did the product meet your expectations? Please explain.",
  "Which specific features of the product do you find most valuable?",
  "On a scale of 1 to 10, how would you rate the ease of use of our product?",
  "How satisfied are you with the customer support you received related to the product?",
  "Did the product offer good value for the price you paid?",
  "How often do you use our product?",
  "Have you encountered any issues with the product? If yes, how were they resolved?",
  "Would you consider purchasing our products again in the future?"
];
const API_BASE_URL = "https://api.surveysparrow.com/v3/";
const headers = {
  options: {
    headers: {
      Authorization: `Bearer <%= iparams.surveysparrow_api_key %>`,
    },
  },
};
var client;
init();
async function init() {
  client = await window.app.initialized();
}
const button = document.getElementById("btn");
const message = document.getElementById("msg");
button.onclick = createSurvey;
async function createSurvey() {
  try {
    button.innerHTML = "Your  report is being created...";
    // Create the Survey
    const surveyId = await postSurvey();
    // Create questions for the Survey
    for (let question of questions) {
      await postQuestion(surveyId, question);
    }
    button.innerHTML = "Create";
    showNotificationMessage("Report Created Successfully", { type: "success" });
  } catch (error) {
    button.innerHTML = "Create";
    console.log("Error while creating the Report", error);
    showNotificationMessage("Error while Creating Survey", { type: "failure" });
  }
}
async function postSurvey() {
  const response = await client.request.post(`${API_BASE_URL}surveys`, headers, {
    name: "Instant Survey",
    survey_type: "ClassicForm",
  });

  return JSON.parse(response).body.data.id;
}
async function postQuestion(surveyId, question) {
  await client.request.post(`${API_BASE_URL}questions`, headers, {
    survey_id: surveyId,
    question: {
      type: "TextInput",
      text: question,
    },
  });
}
function showNotificationMessage(message, options) {
  client.interface.alertMessage(message, options);
  if (options.type === "success") {
    message.innerHTML = "Please navigate to home screen to see newly created Reports.";
    setTimeout(() => {
      message.innerHTML = "";
    }, 3000);
  }
}